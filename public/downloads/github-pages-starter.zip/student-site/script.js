const button = document.getElementById('hello-button');
const greeting = document.getElementById('greeting');
let count = 0;
button.addEventListener('click', () => {
  count += 1;
  greeting.textContent = `收到你的第 ${count} 次招呼，今天也加油。`;
});
