#!/bin/sh
cd "$(dirname "$0")" || exit 1
if command -v python3 >/dev/null 2>&1; then
  python3 server.py
else
  echo "Python 3 was not found. Install Python 3 before the lesson."
fi
printf '\nPress Enter to close...'
read answer
