# 第二节网安课：请求观察站

需要 Python 3（建议 3.10 或更新版本）和 Chrome、Edge 或 Firefox。不需要 pip、Docker、Wireshark 或联网安装依赖。

## 启动

先完整解压文件夹。Windows 双击 `start-lab.bat`，macOS 双击 `start-lab.command`。启动后手动打开 http://127.0.0.1:8765 。窗口保持打开，结束按 Ctrl+C。

macOS 若系统不允许直接运行脚本，可在终端输入 `cd `，把解压后的文件夹拖进去，按回车，再执行：

```bash
python3 server.py
```

Windows 可在文件夹地址栏输入 `cmd`，回车后执行：

```powershell
py -3 server.py
```

不要输入示例提示符 `$`。本课运行的是 `server.py`，不能用普通静态文件服务器替代，否则 `/api/hello` 等实验接口不能工作。

## 四项实验

1. Network 面板点击“发送请求”，记录 URL、方法、状态码、`X-Lab-Port` 与 `X-Lab-Flag` 响应头。
2. 查询 `club.test` 和 `unknown.test`，记录模拟 DNS 回答。它不会配置系统 DNS，不能把 `club.test` 直接输入地址栏来访问本实验。
3. 勾选 Preserve log，依次观察 302、403、404、503。302 后浏览器会继续访问 `/destination`。
4. 比较 8765 和 8766 的响应头，之后停止服务并刷新，比较连接错误与 HTTP 404 的差别。

## 常见问题

- Python 未找到：提前从 https://www.python.org/downloads/ 安装 Python 3，Windows 安装时启用 PATH 选项。
- 端口被占用：关闭之前的实验终端再重试。不要改端口，因为 PPT 和练习引用固定端口。
- 页面打不开：确认终端正在运行、地址以 `http://` 开始，端口为 8765 或 8766。
- `/api/hello` 返回 404：确认使用的是这里的 `server.py`，而非上一课的 `python -m http.server`。
- macOS 脚本权限问题：使用上面的手动终端命令。

两个服务仅绑定 `127.0.0.1`，其他同学不能通过你的局域网 IP 访问。课堂实验无需修改防火墙、hosts 或系统 DNS。
