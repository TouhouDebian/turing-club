"""Offline classroom HTTP lab. Python 3 standard library only."""
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

ROOT = Path(__file__).resolve().parent
HOST = "127.0.0.1"
PORTS = (8765, 8766)


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.respond(False)

    def do_HEAD(self):
        self.respond(True)

    def respond(self, head_only):
        url = urlsplit(self.path)
        status, kind, headers = 200, "text/html; charset=utf-8", {}
        if url.path in ("/", "/index.html"):
            body = (ROOT / "index.html").read_bytes()
        elif url.path == "/assets/cover.png":
            kind = "image/png"
            body = (ROOT / "assets/cover.png").read_bytes()
        elif url.path == "/api/hello":
            kind = "application/json; charset=utf-8"
            name = parse_qs(url.query).get("name", ["Turing"])[0][:50]
            body = json.dumps({"message": "Hello, " + name, "port": self.server.server_port}, ensure_ascii=False).encode()
            headers["X-Lab-Flag"] = "flag{read_the_response_headers}"
        elif url.path == "/api/dns":
            kind = "application/json; charset=utf-8"
            name = parse_qs(url.query).get("name", [""])[0].strip().lower()
            record = {"club.test": "127.0.0.1", "library.test": "192.0.2.10"}.get(name)
            body = json.dumps({"mode": "SIMULATION ONLY - not system DNS", "name": name, "type": "A", "answer": record, "result": "NOERROR" if record else "NXDOMAIN"}).encode()
        elif url.path == "/moved":
            status, headers["Location"] = 302, "/destination"
            body = b"Redirecting to /destination"
        elif url.path == "/destination":
            body = "<meta charset='utf-8'><h1>302 后的新地址</h1><p>在 Network 中保留日志，查看 /moved 和 /destination 两次请求。</p><a href='/'>返回实验站</a>".encode()
        elif url.path == "/forbidden":
            status = 403
            body = "<meta charset='utf-8'><h1>403 Forbidden</h1><p>服务器收到请求，但拒绝提供这个演示资源。这里没有可读取的秘密。</p><a href='/'>返回</a>".encode()
        elif url.path == "/unavailable":
            status = 503
            headers["Retry-After"] = "60"
            body = b"503 Service Unavailable - classroom simulation"
        elif url.path == "/robots.txt":
            kind, body = "text/plain; charset=utf-8", b"User-agent: *\nDisallow: /forbidden\n# This is not access control.\n"
        else:
            status = 404
            body = "<meta charset='utf-8'><h1>404 Not Found</h1><p>服务器可以连接，但这个路径没有对应资源。</p><a href='/'>返回</a>".encode()
        self.send_response(status)
        self.send_header("Content-Type", kind)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Lab-Port", str(self.server.server_port))
        self.send_header("X-Content-Type-Options", "nosniff")
        for name, value in headers.items():
            self.send_header(name, value)
        self.end_headers()
        if not head_only:
            self.wfile.write(body)


def main():
    servers = []
    try:
        for port in PORTS:
            servers.append(ThreadingHTTPServer((HOST, port), Handler))
    except OSError as error:
        for server in servers:
            server.server_close()
        print("Could not listen on 127.0.0.1:8765 and :8766.", error)
        print("Check for an earlier lab window or local permission restrictions.")
        return 1
    for server in servers:
        threading.Thread(target=server.serve_forever, daemon=True).start()
    print("Turing Club Lesson 02 | Offline HTTP lab")
    print("Open http://127.0.0.1:8765 in your browser.")
    print("Second port: http://127.0.0.1:8766")
    print("Only this computer can connect. Press Ctrl+C to stop.")
    try:
        threading.Event().wait()
    except KeyboardInterrupt:
        print("\nStopping lab...")
    finally:
        for server in servers:
            server.shutdown()
            server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
